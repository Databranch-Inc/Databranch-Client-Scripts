// RecordLibraryView.cs — Phase 5 stub
using System.Windows.Forms;
using ArnotOnboarding.Theme;
namespace ArnotOnboarding.Views
{
    public partial class RecordLibraryView : UserControl
    {
        public RecordLibraryView() { InitializeComponent(); ThemeHelper.ApplyTheme(this); }
    }
}
